# Topsis-Python-Package
A python file with function to implement topsis. The function takes a csv file path and weights of each coloumn and also a list denoting if it has positive or negative effect on ranking.

#Usage
Following query on terminal will provide you the rank of the csv file path according to weights and z provided.

just an e.g. for file Newdata.csv with weight og each column being 1 and z as shown below
topsis -f 'C:/Users/g s khagta/Downloads/Newdata.csv' -w 1 1 1 1 -z - + + +